/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package partnersuche;

/**
 *
 * @author kreienbaum
 */
public class user {

    private String name;
    private int alter;
    private Geschlecht geschlecht;
    private Orientierung orientierung;
    private Hobbies hobbies;

    public user(String name,Geschlecht geschlecht, int alter, Orientierung orientierung, Hobbies hobbies) {
        this.geschlecht = geschlecht;
        this.name = name;
        this.alter = alter;
        this.orientierung = orientierung;
        this.hobbies = hobbies;

    }

    public String getName() {
        return name;

    }

    public int getAlter() {
        return alter;
    }
    Geschlecht getGeschlecht(){
        return geschlecht;
    }

    public Orientierung getOrientierung() {
        return orientierung;

    }
    public Hobbies getHobbies(){
        return hobbies;
    }
    public String getDetails(){
        String details = "";
        details += "\nName: " + name +"\n";
        details += "Geschlecht: " + geschlecht + "\n";
        details += "Alter: " + alter + "\n";
        details += "Orientierung: " + orientierung + "\n";
        details += "Hobbies: " + hobbies + "\n";
        return details;
    }
}
