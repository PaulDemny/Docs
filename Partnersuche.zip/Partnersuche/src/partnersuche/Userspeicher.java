/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package partnersuche;

import java.util.List;
import java.util.LinkedList;

/**
 *
 * @author kreienbaum
 */
public class Userspeicher {
    
    private LinkedList <User> speicher; 
    
    public Userspeicher(){
        this.speicher = new LinkedList<>();
        this.init();
    }

    /**
     * init() - Methode init Liste
     */
    private void init() {
        this.speicher.add(new User("Max Mustermann", User.Geschlecht.Mann, 33, User.Orientierung.Frauen, User.Hobbies.Handball));
        /*
        alleuser[0] = new User("Max Mustermann", User.Geschlecht.Mann, 33, User.Orientierung.Frauen, User.Hobbies.Handball);
        alleuser[1] = new User("Maria Magdalena", User.Geschlecht.Frau, 85, User.Orientierung.Maenner, User.Hobbies.Volleyball);
        alleuser[2] = new User("Hans Wurst", User.Geschlecht.Mann, 25, User.Orientierung.Maenner, User.Hobbies.Handball);
        alleuser[3] = new User("Karl Laemmle", User.Geschlecht.Mann, 37, User.Orientierung.Frauen, User.Hobbies.Reiten);
        alleuser[4] = new User("Lisa Leder", User.Geschlecht.Frau, 23, User.Orientierung.Maenner, User.Hobbies.Ski);
        alleuser[5] = new User("Anja Ackermann", User.Geschlecht.Frau, 19, User.Orientierung.Maenner, User.Hobbies.Hockey);
        alleuser[6] = new User("Beate Uhse", User.Geschlecht.Frau, 49, User.Orientierung.Maenner, User.Hobbies.Reiten);
        alleuser[7] = new User("Christina Chrome", User.Geschlecht.Frau, 20, User.Orientierung.Maenner, User.Hobbies.Snowboard);
        alleuser[8] = new User("Doris Dull", User.Geschlecht.Frau, 58, User.Orientierung.Frauen, User.Hobbies.Football);
        alleuser[9] = new User("Erika Eckart", User.Geschlecht.Frau, 34, User.Orientierung.Maenner, User.Hobbies.Fussball);
        alleuser[10] = new User("Franziska Friedrich", User.Geschlecht.Frau, 65, User.Orientierung.Maenner, User.Hobbies.Hockey);
        alleuser[11] = new User("Gerda Gremlin", User.Geschlecht.Frau, 21, User.Orientierung.Frauen, User.Hobbies.Snowboard);
        alleuser[12] = new User("Helga, Die Helga", User.Geschlecht.Frau, 24, User.Orientierung.Maenner, User.Hobbies.Volleyball);
        alleuser[13] = new User("Ibrahim der Inder", User.Geschlecht.Mann, 29, User.Orientierung.Frauen, User.Hobbies.Fussball);
        alleuser[14] = new User("Jonathan Junkers", User.Geschlecht.Mann, 49, User.Orientierung.Frauen, User.Hobbies.Football);
        alleuser[15] = new User("Norman Neymar", User.Geschlecht.Mann, 35, User.Orientierung.Frauen, User.Hobbies.Hockey);
        alleuser[16] = new User("Omar Ojcauhsacz", User.Geschlecht.Mann, 68, User.Orientierung.Maenner, User.Hobbies.Reiten);
        alleuser[17] = new User("Peter Pavlov", User.Geschlecht.Mann, 28, User.Orientierung.Frauen, User.Hobbies.Snowboard);
        alleuser[18] = new User("Rainer Zufall", User.Geschlecht.Mann, 88, User.Orientierung.Frauen, User.Hobbies.Hockey);
        alleuser[19] = new User("Stefan Saufried", User.Geschlecht.Mann, 27, User.Orientierung.Frauen, User.Hobbies.Handball);
*/
    }
    
    public LinkedList <User> getSpeicher(){
        LinkedList <User> liste = null;
        try{
            liste = this.speicher;
        }
        catch(Exception ex){
            liste = null;
        }
        return liste;
    }
}
