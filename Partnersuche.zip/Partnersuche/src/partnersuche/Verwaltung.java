/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package partnersuche;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author kreienbaum
 */
public class Verwaltung {

    private Userspeicher speicher;

    public Verwaltung() {
        this.speicher = new Userspeicher();
    }

    public List <User> suche(int alter1, int alter2) {
        if (alter1 <=18 | alter1 >=99){
            alter1 = 18;
        }
        if (alter2 < alter1 | alter2 <=19 | alter2>=99){
            alter2 = 99;
        }
        int gefunden = 0;
        List <User> foundusers = new LinkedList<>();

        for (int s = 0; s <= 1; s++) {

            int idx = 0;

            for (int i = 0; i < this.speicher.getSpeicher().size(); i++){
                if (this.speicher.getSpeicher().get(i).getAlter() >= alter1 && alleuser[i].getAlter() <= alter2) {

                    if (s > 0) {
                        foundusers[idx++] = alleuser[i];

                    } else {
                        gefunden++;
                    }
                }
            }
        }
        return foundusers;
    }

    User[] suche(String eingabeorientierung, User[] results) {
        int gefunden = 0;
        User[] foundusers = null;

        for (int s = 0; s <= 1; s++) {

            int idx = 0;

            if (s > 0) {
                foundusers = new User[gefunden];
            }

            for (int i = 0; i < results.length; i++) {
                if (results[i].getOrientierung().toString().equals(eingabeorientierung)) {

                    if (s > 0) {
                        foundusers[idx++] = results[i];

                    } else {
                        gefunden++;
                    }
                }
            }
        }
        return foundusers;
    }

    User[] suche(String eingabehobbies, User[] results, String b) {
        int gefunden = 0;
        User[] foundusers = null;

        for (int s = 0; s <= 1; s++) {

            int idx = 0;

            if (s > 0) {
                foundusers = new User[gefunden];
            }

            for (int i = 0; i < results.length; i++) {
                if (results[i].getHobbies().toString().equals(eingabehobbies)) {

                    if (s > 0) {
                        foundusers[idx++] = results[i];

                    } else {
                        gefunden++;
                    }
                }
            }
        }
        return foundusers;
    }

    //Suche nach m / w fehlt noch
    User[] suche(int geschl, User[] results) {
        String geschlecht = "";

        switch (geschl) {
            case 0:
                geschlecht = "Mann";
                break;
            case 1:
                geschlecht = "Frau";
                break;

        }

        int gefunden = 0;
        User[] foundusers = null;

        for (int s = 0; s <= 1; s++) {

            int idx = 0;

            if (s > 0) {
                foundusers = new User[gefunden];
            }

            for (int i = 0; i < results.length; i++) {
                if (results[i].getGeschlecht().toString().equals(geschlecht)) {

                    if (s > 0) {
                        foundusers[idx++] = results[i];

                    } else {
                        gefunden++;
                    }
                }
            }
        }
        return foundusers;
    }
}
